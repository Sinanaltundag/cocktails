import React from 'react'
import Cocktail from './Cocktail'
import { useGlobalContext } from './Context';

const Cocktails = () => {
    const {cocktails,apiData, searchWord} = useGlobalContext();
  return (
    <div>
    {searchWord.length>1 ? (cocktails.map(cocktail =>{
    return (
        <Cocktail {...cocktail} key={cocktail.id}/>
    )
})): (apiData.map(cocktail =>{
    return (
        <Cocktail {...cocktail} key={cocktail.id}/>
    )
}))}


    </div>
  )
}

export default Cocktails