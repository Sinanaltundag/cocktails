import React from "react";
import Cocktails from "./Cocktails";
import Search from "./Search";
// import { useGlobalContext } from './Context'

const Main = () => {
  // const {handleClick, setHello}=useGlobalContext();
  return (
    <div>
    <Search/>

      <div className="container">
        <h1>Cocktails</h1>
        <Cocktails/>
      </div>
    </div>
  );
};

export default Main;
