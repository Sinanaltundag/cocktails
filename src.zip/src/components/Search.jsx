import React from "react";
import { useGlobalContext } from "./Context";

const Search = () => {
  const {handleChange,searchWord,setSearchWord} = useGlobalContext();
  // console.log(searchWord)
  return (
    
      <div className="container">
        <label htmlFor="search">Search Your Favorite Cocktail</label>
        <br />
        <input type="text" id="search" onChange={(e)=>setSearchWord(e.target.value)} value={searchWord}/>
      </div>
   
  );
};

export default Search;
