import "./App.css";
// import { useGlobalContext } from './components/Context';
import Main from "./components/Main";
import NavBar from "./components/NavBar";
import { BrowserRouter } from "react-router-dom";
import { Routes, Route, Link } from "react-router-dom";
import SingleCocktail from "./components/SingleCocktail";

function App() {
  // const {hello} = useGlobalContext();

  return (
    <div className="App">
      <BrowserRouter>
        <NavBar />
        <Routes>
<Route path="/" element={<Main />}/>
<Route path="/cocktail/:id" element={<SingleCocktail />}/>

          
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
